import React from 'react';

//components
import RenterSidebar from "../../components/navigation/RenterSidebar";

function TableNext10Bookings({isAuthenticated,user}) {

    return (
        <div>

        </div>
    );
}

export default TableNext10Bookings;

